/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author Shanika
 */
public class RemoveDoctor {
    public static void removeDoctor(int doctorId) throws SQLException {
        String sql = "DELETE FROM doctor WHERE doctor_ID = ?";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, doctorId);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("No Doctor found with this Doctor ID: " + doctorId);
            }
        } catch (SQLException e) {
            throw new SQLException("Error removing Doctor: " + e.getMessage(), e);
        }
    }

}
