/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Shanika
 */
import java.sql.Connection; 
import java.sql.DriverManager; 
import java.sql.PreparedStatement;
import java.sql.SQLException; 
import java.sql.Statement;

public class DBConnection {
    private static Connection conn;
    private static Statement stat;
    private static final String URL = "jdbc:mysql://localhost:3306/hospitaldb";
    private static final String USER = "root"; 
    private static final String PASSWORD = ""; 
   
public static Statement getStatementConnection() {
         try {

         String url = "jdbc:mysql://localhost:3306/hospitaldb";
         conn = DriverManager.getConnection(url, "root", "");

            stat = conn.createStatement();
       
        } catch (SQLException e) {
        }
           return stat;
        }
    
public static void closeCon() throws SQLException {
        conn.close();
    }

    static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
       
    }

    static Connection conn() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public PreparedStatement preparedStatement() throws SQLException {
        if (conn == null || conn.isClosed()) {
            getConnection();
        }
        String query = null;
        return conn.prepareStatement(query);
    }

    
}
