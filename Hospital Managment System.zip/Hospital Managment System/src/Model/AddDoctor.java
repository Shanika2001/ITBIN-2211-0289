/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author Shanika
 */
public class AddDoctor {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/hospitaldb";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    public void addDoctor(String doctorName, int age, String address, Object gender, String eduQualify, String profQualify, int wardNo, int contact) throws SQLException {
         {
        String query = "INSERT INTO doctor (doctor_Name, age, address, gender, edu_Qualify, prof_Qalify, ward_No, contact) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement statement = connection.prepareStatement(query)) {

           
            statement.setString(1, doctorName);
            statement.setInt(2, age);
            statement.setString(3, address);
            statement.setObject(4, gender);
            statement.setString(5, eduQualify);
            statement.setString(6, profQualify);
            statement.setInt(7, wardNo);
            statement.setInt(8, contact);
            

            statement.executeUpdate();
        } catch (SQLException e) {
            throw new SQLException("Error adding account: " + e.getMessage());
        }
    }
    
    
    }
}

  

