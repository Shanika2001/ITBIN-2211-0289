/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.AddDoctor;
import Model.RemoveDoctor;
import java.sql.SQLException;

/**
 *
 * @author Shanika
 */
public class DoctorController {
    public static void addDoctor(String doctorName, int age, String address, Object gender, String eduQualify, String profQualify, int wardNo, int contact)
                 throws SQLException {
        AddDoctor addDoctor = new AddDoctor();
        addDoctor.addDoctor(doctorName, age, address, gender, eduQualify, profQualify, wardNo, contact);
    }

    public void removeDoctor(int doctorId) throws SQLException {
        RemoveDoctor.removeDoctor(doctorId);
    }


    
}
