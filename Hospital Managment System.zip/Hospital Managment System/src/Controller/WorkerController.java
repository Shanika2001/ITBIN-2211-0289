/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.AddWorker;
import Model.RemoveDoctor;
import Model.RemoveWorker;
import java.sql.SQLException;

/**
 *
 * @author Shanika
 */
public class WorkerController {
    public static void addWorker(String workerName, int age, String address, String proffesion, String gender, String contact, int wardNo)
                 throws SQLException {
        AddWorker addWorker = new AddWorker();
        addWorker.addWorker(workerName, age, address, proffesion, gender, contact, wardNo);
    }

    public void removeWorker(int workerID) throws SQLException {
        RemoveWorker.removeWorker(workerID);
    }
}
